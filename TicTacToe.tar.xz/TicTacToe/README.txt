Setup

---------------------------------------

1) open terminal and
   navigate to the
   directory that contains
   this file.

2) then, type "./setup.sh".
   if it says "premission denied",
   first type "chmod u+x ./setup.sh",
   then "./setup.sh", and enter
   the required password.

3) go to the desktop and
   search for a file called
   "tictactoe.desktop".
   right click it and choose
   "Allow Launching".

Note: to start it from the terminal type /usr/bin/TicTacToe

