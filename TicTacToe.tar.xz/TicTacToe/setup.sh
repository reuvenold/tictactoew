sudo mkdir /usr/share/icons/ttt
sudo cp ./favicon.png /usr/share/icons/ttt/
sudo cp ./TicTacToe /usr/bin/
cp ./tictactoe.desktop ~/Desktop/
cp ./tictactoe.desktop ~/.local/share/applications/